| Feature | Description |
| --- | --- |
| **Name** | `en_organic_food` |
| **Version** | `0.0.0` |
| **spaCy** | `>=3.1.5,<3.2.0` |
| **Default Pipeline** | `textcat_multilabel` |
| **Components** | `textcat_multilabel` |
| **Vectors** | 0 keys, 0 unique vectors (0 dimensions) |
| **Sources** | n/a |
| **License** | n/a |
| **Author** | [n/a]() |

### Label Scheme

<details>

<summary>View label scheme (1 labels for 1 components)</summary>

| Component | Labels |
| --- | --- |
| **`textcat_multilabel`** | `organic_food` |

</details>

### Accuracy

| Type | Score |
| --- | --- |
| `CATS_SCORE` | 89.72 |
| `CATS_MICRO_P` | 90.91 |
| `CATS_MICRO_R` | 100.00 |
| `CATS_MICRO_F` | 95.24 |
| `CATS_MACRO_P` | 90.91 |
| `CATS_MACRO_R` | 100.00 |
| `CATS_MACRO_F` | 95.24 |
| `CATS_MACRO_AUC` | 89.72 |
| `CATS_MACRO_AUC_PER_TYPE` | 0.00 |
| `TEXTCAT_MULTILABEL_LOSS` | 2316.43 |