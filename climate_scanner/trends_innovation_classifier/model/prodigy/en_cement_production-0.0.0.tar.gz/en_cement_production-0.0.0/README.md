| Feature | Description |
| --- | --- |
| **Name** | `en_cement_production` |
| **Version** | `0.0.0` |
| **spaCy** | `>=3.1.5,<3.2.0` |
| **Default Pipeline** | `textcat_multilabel` |
| **Components** | `textcat_multilabel` |
| **Vectors** | 0 keys, 0 unique vectors (0 dimensions) |
| **Sources** | n/a |
| **License** | n/a |
| **Author** | [n/a]() |

### Label Scheme

<details>

<summary>View label scheme (1 labels for 1 components)</summary>

| Component | Labels |
| --- | --- |
| **`textcat_multilabel`** | `cement_production` |

</details>

### Accuracy

| Type | Score |
| --- | --- |
| `CATS_SCORE` | 93.06 |
| `CATS_MICRO_P` | 78.95 |
| `CATS_MICRO_R` | 93.75 |
| `CATS_MICRO_F` | 85.71 |
| `CATS_MACRO_P` | 78.95 |
| `CATS_MACRO_R` | 93.75 |
| `CATS_MACRO_F` | 85.71 |
| `CATS_MACRO_AUC` | 93.06 |
| `CATS_MACRO_AUC_PER_TYPE` | 0.00 |
| `TEXTCAT_MULTILABEL_LOSS` | 0.43 |