| Feature | Description |
| --- | --- |
| **Name** | `en_fiber_optic_cables` |
| **Version** | `0.0.0` |
| **spaCy** | `>=3.1.5,<3.2.0` |
| **Default Pipeline** | `textcat_multilabel` |
| **Components** | `textcat_multilabel` |
| **Vectors** | 0 keys, 0 unique vectors (0 dimensions) |
| **Sources** | n/a |
| **License** | n/a |
| **Author** | [n/a]() |

### Label Scheme

<details>

<summary>View label scheme (1 labels for 1 components)</summary>

| Component | Labels |
| --- | --- |
| **`textcat_multilabel`** | `fiber_optic_cables` |

</details>

### Accuracy

| Type | Score |
| --- | --- |
| `CATS_SCORE` | 91.13 |
| `CATS_MICRO_P` | 77.19 |
| `CATS_MICRO_R` | 93.62 |
| `CATS_MICRO_F` | 84.62 |
| `CATS_MACRO_P` | 77.19 |
| `CATS_MACRO_R` | 93.62 |
| `CATS_MACRO_F` | 84.62 |
| `CATS_MACRO_AUC` | 91.13 |
| `CATS_MACRO_AUC_PER_TYPE` | 0.00 |
| `TEXTCAT_MULTILABEL_LOSS` | 1017.98 |