| Feature | Description |
| --- | --- |
| **Name** | `en_e_health` |
| **Version** | `0.0.0` |
| **spaCy** | `>=3.1.5,<3.2.0` |
| **Default Pipeline** | `textcat_multilabel` |
| **Components** | `textcat_multilabel` |
| **Vectors** | 0 keys, 0 unique vectors (0 dimensions) |
| **Sources** | n/a |
| **License** | n/a |
| **Author** | [n/a]() |

### Label Scheme

<details>

<summary>View label scheme (1 labels for 1 components)</summary>

| Component | Labels |
| --- | --- |
| **`textcat_multilabel`** | `e_health` |

</details>

### Accuracy

| Type | Score |
| --- | --- |
| `CATS_SCORE` | 87.47 |
| `CATS_MICRO_P` | 82.64 |
| `CATS_MICRO_R` | 88.50 |
| `CATS_MICRO_F` | 85.47 |
| `CATS_MACRO_P` | 82.64 |
| `CATS_MACRO_R` | 88.50 |
| `CATS_MACRO_F` | 85.47 |
| `CATS_MACRO_AUC` | 87.47 |
| `CATS_MACRO_AUC_PER_TYPE` | 0.00 |
| `TEXTCAT_MULTILABEL_LOSS` | 321.56 |