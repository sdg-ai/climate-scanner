| Feature | Description |
| --- | --- |
| **Name** | `en_smart_food_management_kitchen_fridges_freezers` |
| **Version** | `0.0.0` |
| **spaCy** | `>=3.1.5,<3.2.0` |
| **Default Pipeline** | `textcat_multilabel` |
| **Components** | `textcat_multilabel` |
| **Vectors** | 0 keys, 0 unique vectors (0 dimensions) |
| **Sources** | n/a |
| **License** | n/a |
| **Author** | [n/a]() |

### Label Scheme

<details>

<summary>View label scheme (1 labels for 1 components)</summary>

| Component | Labels |
| --- | --- |
| **`textcat_multilabel`** | `smart_food_management_kitchen_fridges_freezers` |

</details>

### Accuracy

| Type | Score |
| --- | --- |
| `CATS_SCORE` | 82.39 |
| `CATS_MICRO_P` | 86.73 |
| `CATS_MICRO_R` | 96.59 |
| `CATS_MICRO_F` | 91.40 |
| `CATS_MACRO_P` | 86.73 |
| `CATS_MACRO_R` | 96.59 |
| `CATS_MACRO_F` | 91.40 |
| `CATS_MACRO_AUC` | 82.39 |
| `CATS_MACRO_AUC_PER_TYPE` | 0.00 |
| `TEXTCAT_MULTILABEL_LOSS` | 772.27 |