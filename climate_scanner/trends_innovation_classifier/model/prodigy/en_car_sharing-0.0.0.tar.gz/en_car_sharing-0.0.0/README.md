| Feature | Description |
| --- | --- |
| **Name** | `en_car_sharing` |
| **Version** | `0.0.0` |
| **spaCy** | `>=3.1.5,<3.2.0` |
| **Default Pipeline** | `textcat_multilabel` |
| **Components** | `textcat_multilabel` |
| **Vectors** | 0 keys, 0 unique vectors (0 dimensions) |
| **Sources** | n/a |
| **License** | n/a |
| **Author** | [n/a]() |

### Label Scheme

<details>

<summary>View label scheme (1 labels for 1 components)</summary>

| Component | Labels |
| --- | --- |
| **`textcat_multilabel`** | `car_sharing` |

</details>

### Accuracy

| Type | Score |
| --- | --- |
| `CATS_SCORE` | 67.78 |
| `CATS_MICRO_P` | 70.83 |
| `CATS_MICRO_R` | 70.83 |
| `CATS_MICRO_F` | 70.83 |
| `CATS_MACRO_P` | 70.83 |
| `CATS_MACRO_R` | 70.83 |
| `CATS_MACRO_F` | 70.83 |
| `CATS_MACRO_AUC` | 67.78 |
| `CATS_MACRO_AUC_PER_TYPE` | 0.00 |
| `TEXTCAT_MULTILABEL_LOSS` | 3.89 |