| Feature | Description |
| --- | --- |
| **Name** | `en_electric_car` |
| **Version** | `0.0.0` |
| **spaCy** | `>=3.1.5,<3.2.0` |
| **Default Pipeline** | `textcat_multilabel` |
| **Components** | `textcat_multilabel` |
| **Vectors** | 0 keys, 0 unique vectors (0 dimensions) |
| **Sources** | n/a |
| **License** | n/a |
| **Author** | [n/a]() |

### Label Scheme

<details>

<summary>View label scheme (1 labels for 1 components)</summary>

| Component | Labels |
| --- | --- |
| **`textcat_multilabel`** | `electric_car` |

</details>

### Accuracy

| Type | Score |
| --- | --- |
| `CATS_SCORE` | 88.39 |
| `CATS_MICRO_P` | 85.29 |
| `CATS_MICRO_R` | 93.55 |
| `CATS_MICRO_F` | 89.23 |
| `CATS_MACRO_P` | 85.29 |
| `CATS_MACRO_R` | 93.55 |
| `CATS_MACRO_F` | 89.23 |
| `CATS_MACRO_AUC` | 88.39 |
| `CATS_MACRO_AUC_PER_TYPE` | 0.00 |
| `TEXTCAT_MULTILABEL_LOSS` | 0.77 |