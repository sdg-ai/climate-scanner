| Feature | Description |
| --- | --- |
| **Name** | `en_shipping` |
| **Version** | `0.0.0` |
| **spaCy** | `>=3.1.5,<3.2.0` |
| **Default Pipeline** | `textcat_multilabel` |
| **Components** | `textcat_multilabel` |
| **Vectors** | 0 keys, 0 unique vectors (0 dimensions) |
| **Sources** | n/a |
| **License** | n/a |
| **Author** | [n/a]() |

### Label Scheme

<details>

<summary>View label scheme (1 labels for 1 components)</summary>

| Component | Labels |
| --- | --- |
| **`textcat_multilabel`** | `shipping` |

</details>

### Accuracy

| Type | Score |
| --- | --- |
| `CATS_SCORE` | 88.95 |
| `CATS_MICRO_P` | 73.21 |
| `CATS_MICRO_R` | 100.00 |
| `CATS_MICRO_F` | 84.54 |
| `CATS_MACRO_P` | 73.21 |
| `CATS_MACRO_R` | 100.00 |
| `CATS_MACRO_F` | 84.54 |
| `CATS_MACRO_AUC` | 88.95 |
| `CATS_MACRO_AUC_PER_TYPE` | 0.00 |
| `TEXTCAT_MULTILABEL_LOSS` | 3018.95 |