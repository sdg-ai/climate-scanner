| Feature | Description |
| --- | --- |
| **Name** | `en_clothes_designed_for_a_circular_economy` |
| **Version** | `0.0.0` |
| **spaCy** | `>=3.1.5,<3.2.0` |
| **Default Pipeline** | `textcat_multilabel` |
| **Components** | `textcat_multilabel` |
| **Vectors** | 0 keys, 0 unique vectors (0 dimensions) |
| **Sources** | n/a |
| **License** | n/a |
| **Author** | [n/a]() |

### Label Scheme

<details>

<summary>View label scheme (1 labels for 1 components)</summary>

| Component | Labels |
| --- | --- |
| **`textcat_multilabel`** | `clothes_designed_for_a_circular_economy` |

</details>

### Accuracy

| Type | Score |
| --- | --- |
| `CATS_SCORE` | 85.42 |
| `CATS_MICRO_P` | 86.21 |
| `CATS_MICRO_R` | 91.46 |
| `CATS_MICRO_F` | 88.76 |
| `CATS_MACRO_P` | 86.21 |
| `CATS_MACRO_R` | 91.46 |
| `CATS_MACRO_F` | 88.76 |
| `CATS_MACRO_AUC` | 85.42 |
| `CATS_MACRO_AUC_PER_TYPE` | 0.00 |
| `TEXTCAT_MULTILABEL_LOSS` | 47.23 |