| Feature | Description |
| --- | --- |
| **Name** | `en_3d_printed_clothes` |
| **Version** | `0.0.0` |
| **spaCy** | `>=3.1.5,<3.2.0` |
| **Default Pipeline** | `textcat_multilabel` |
| **Components** | `textcat_multilabel` |
| **Vectors** | 0 keys, 0 unique vectors (0 dimensions) |
| **Sources** | n/a |
| **License** | n/a |
| **Author** | [n/a]() |

### Label Scheme

<details>

<summary>View label scheme (1 labels for 1 components)</summary>

| Component | Labels |
| --- | --- |
| **`textcat_multilabel`** | `3d_printed_clothes` |

</details>

### Accuracy

| Type | Score |
| --- | --- |
| `CATS_SCORE` | 84.85 |
| `CATS_MICRO_P` | 83.75 |
| `CATS_MICRO_R` | 84.81 |
| `CATS_MICRO_F` | 84.28 |
| `CATS_MACRO_P` | 83.75 |
| `CATS_MACRO_R` | 84.81 |
| `CATS_MACRO_F` | 84.28 |
| `CATS_MACRO_AUC` | 84.85 |
| `CATS_MACRO_AUC_PER_TYPE` | 0.00 |
| `TEXTCAT_MULTILABEL_LOSS` | 0.03 |