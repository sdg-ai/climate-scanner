| Feature | Description |
| --- | --- |
| **Name** | `en_biking` |
| **Version** | `0.0.0` |
| **spaCy** | `>=3.1.5,<3.2.0` |
| **Default Pipeline** | `textcat_multilabel` |
| **Components** | `textcat_multilabel` |
| **Vectors** | 0 keys, 0 unique vectors (0 dimensions) |
| **Sources** | n/a |
| **License** | n/a |
| **Author** | [n/a]() |

### Label Scheme

<details>

<summary>View label scheme (1 labels for 1 components)</summary>

| Component | Labels |
| --- | --- |
| **`textcat_multilabel`** | `biking` |

</details>

### Accuracy

| Type | Score |
| --- | --- |
| `CATS_SCORE` | 70.77 |
| `CATS_MICRO_P` | 89.47 |
| `CATS_MICRO_R` | 100.00 |
| `CATS_MICRO_F` | 94.44 |
| `CATS_MACRO_P` | 89.47 |
| `CATS_MACRO_R` | 100.00 |
| `CATS_MACRO_F` | 94.44 |
| `CATS_MACRO_AUC` | 70.77 |
| `CATS_MACRO_AUC_PER_TYPE` | 0.00 |
| `TEXTCAT_MULTILABEL_LOSS` | 2897.32 |