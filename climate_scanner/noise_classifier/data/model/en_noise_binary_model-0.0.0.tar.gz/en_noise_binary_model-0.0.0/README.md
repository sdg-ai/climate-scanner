| Feature | Description |
| --- | --- |
| **Name** | `en_noise_binary_model` |
| **Version** | `0.0.0` |
| **spaCy** | `>=3.1.5,<3.2.0` |
| **Default Pipeline** | `textcat_multilabel` |
| **Components** | `textcat_multilabel` |
| **Vectors** | 0 keys, 0 unique vectors (0 dimensions) |
| **Sources** | n/a |
| **License** | n/a |
| **Author** | [n/a]() |

### Label Scheme

<details>

<summary>View label scheme (1 labels for 1 components)</summary>

| Component | Labels |
| --- | --- |
| **`textcat_multilabel`** | `BODY` |

</details>

### Accuracy

| Type | Score |
| --- | --- |
| `CATS_SCORE` | 92.21 |
| `CATS_MICRO_P` | 91.41 |
| `CATS_MICRO_R` | 87.05 |
| `CATS_MICRO_F` | 89.17 |
| `CATS_MACRO_P` | 91.41 |
| `CATS_MACRO_R` | 87.05 |
| `CATS_MACRO_F` | 89.17 |
| `CATS_MACRO_AUC` | 92.21 |
| `CATS_MACRO_AUC_PER_TYPE` | 0.00 |
| `TEXTCAT_MULTILABEL_LOSS` | 5.01 |